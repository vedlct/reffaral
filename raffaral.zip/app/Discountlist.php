<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Discountlist extends Model
{
    //
    protected $table = 'discountlist';
    public $primaryKey = 'discountlistid';
    public $timestamps = false;
}

