<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Referemail extends Model
{
    //
    protected $table = 'refertable';
    public $timestamps = false;
}
