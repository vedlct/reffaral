<?php $__env->startSection('header'); ?>

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.bootstrap4.min.css">

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <div class="panel-header panel-header-sm">
    </div>
    <div class="content">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="title">Send Emails</h5>
                    </div>
                    <div class="card-body">
                        


                        <div class="form-group">
                            <div class="row">
                                <label class="control-label col-md-2">Discount</label>
                                <input type="text" class="col-md-8  form-control" id="discount" name="discount" placeholder="Discount Amount" >
                            </div>

                        </div>

                        <div class="form-group">
                            <div class="row">
                                <label class="control-label col-md-2 " for="exampleInputEmail">Email</label>

                                <select  class="form-control col-md-8 " id="template" name="template">
                                    <option value="">Select Template</option>
                                    <?php $__currentLoopData = $template; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($template->templateid); ?>"><?php echo e($template->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                        </div>
                        <br>

                        <table id="example" class="table table-striped table-bordered" style="width:100%">
                            <thead>

                            <tr>

                                <th>Select</th>
                                <th>Name</th>
                                <th>Email</th>

                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $clientInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><input data-panel-id="<?php echo e($client->clinetinfoid); ?>" onclick="selected_rows(this)"class="chk" name="selected_rows[]" type="checkbox"></td>
                                    <td><?php echo e($client->clientname); ?></td>
                                    <td><?php echo e($client->email); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>



                        <br>

                        <div class="form-group">
                            <div style="margin-left: 14%" class="col-md-8 custom-input-style">
                                <a onclick="sendMail()" class="btn btn-primary">Submit</a>
                            </div>
                        </div>

                        
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('foot-js'); ?>

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

    <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/dataTables.bootstrap4.min.js"></script>


    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $(document).ready( function () {
            $('#example').DataTable();
        } );
        var selecteds = [];
        function selected_rows(x) {
            btn = $(x).data('panel-id');
            var index = selecteds.indexOf(btn)
            if (index == "-1"){
                selecteds.push(btn);
            }else {
                selecteds.splice(index, 1);
            }
        }
        function sendMail() {
            var client=selecteds;
            if (client.length >0) {
                var discount =$('#discount').val();
                var template =$('#template').val();
                var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
                $.ajax({
                    type: 'POST',
                    url: "<?php echo route('email.sendMail'); ?>",
                    cache: false,
                    data: {_token: CSRF_TOKEN,'discount': discount,'template':template,'client':client},
                    success: function (data) {
                        selecteds=[];
                        $(':checkbox:checked').prop('checked',false);
                    }
                });
            }
            else {
                alert("Please Select a Client first");
            }
        }
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>