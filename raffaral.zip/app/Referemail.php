<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Referemail extends Model
{
    //
    protected $table = 'referemail';
    public $primaryKey = 'id';
    public $timestamps = false;
}
