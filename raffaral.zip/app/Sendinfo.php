<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sendinfo extends Model
{
    public $table = 'sendinfo';
    public $timestamps = false;
    public $primaryKey = 'sendinfoid';
}