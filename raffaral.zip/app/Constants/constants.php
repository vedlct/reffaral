<?php
define('Template',array("send Invite Code For Discount"));
define('Admin_email',array("sakibtcl@gmail.com"));





