<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Referordered extends Model
{
    //
    protected $table = 'referordered';
    public $primaryKey = 'referorderedId';
    public $timestamps = false;
}
